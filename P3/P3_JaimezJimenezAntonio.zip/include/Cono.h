#ifndef _CONO
#define _CONO


#include <GL/gl.h>
#include <GL/glut.h>
#include <cstdlib>
#include <vector>
#include "vertex.h"
#include "O3ds.h"
#include "O3d.h"
#include "ORev.h"

using namespace std;

class Cono : public ORev{

  public:

    Cono();


  private:


};





#endif
