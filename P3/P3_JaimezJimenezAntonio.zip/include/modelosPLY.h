#ifndef _MODELOPLY
#define _MODELOPLY

#include "O3d.h"
#include "file_ply_stl.h"

class modelosPLY : public O3d{
	public:

	modelosPLY();
	modelosPLY(string ruta);

};




#endif
