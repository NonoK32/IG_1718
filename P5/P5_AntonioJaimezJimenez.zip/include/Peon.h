#ifndef _PEON
#define _PEON


#include <GL/gl.h>
#include <GL/glut.h>
#include <cstdlib>
#include <vector>
#include "vertex.h"
#include "O3ds.h"
#include "O3d.h"
#include "ORev.h"

using namespace std;

class Peon : public ORev{

  public:

    Peon();


  private:


};





#endif
