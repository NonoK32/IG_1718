#ifndef _TETRAEDRO
#define _TETRAEDRO

#include "O3d.h"

using namespace std;

class Tetraedro : public O3d{

  public:

    Tetraedro();
    

};

#endif
