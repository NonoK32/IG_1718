#ifndef _TABLERO
#define _TABLERO


#include <GL/gl.h>
#include <GL/glut.h>
#include "O3d.h"

using namespace std;


class Tablero : public O3d{

  public:

    Tablero();
    Tablero(int m);

  private:




};






#endif
