#ifndef _VASOINVERTIDO
#define _VASOINVERTIDO


#include <GL/gl.h>
#include <GL/glut.h>
#include <cstdlib>
#include <vector>
#include "vertex.h"
#include "O3ds.h"
#include "O3d.h"
#include "ORev.h"

using namespace std;

class VasoInvertido : public ORev{

  public:

    VasoInvertido();


  private:


};





#endif
