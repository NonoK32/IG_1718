#ifndef _CUBO
#define _CUBO

#include "O3d.h"

using namespace std;

class Cubo : public O3d{

  public:

    Cubo();

};

#endif
